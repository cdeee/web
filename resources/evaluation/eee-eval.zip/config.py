"""
Economic Event Extraction
#########################

Evaluation configuration

@author: Jan R. Benetka
"""


#EVALUATION SETTINGS

"""
how many % difference
of financial value to tolerate
"""
EVAL_MONEY_TOLERANCE_PERCENT = -1

"""
how many years difference
to tolerate (only full yrs)
"""
EVAL_DATE_TOLERANCE_YEARS = -1
